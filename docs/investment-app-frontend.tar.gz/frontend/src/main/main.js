const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const isDev = process.env.NODE_ENV === 'development';

// Importar handlers IPC
require('./ipc-handlers');

class WindowManager {
  constructor() {
    this.mainWindow = null;
  }

  createMainWindow() {
    // Criar a janela principal
    this.mainWindow = new BrowserWindow({
      width: 1400,
      height: 900,
      minWidth: 1200,
      minHeight: 700,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        enableRemoteModule: false,
        preload: path.join(__dirname, '../preload/preload.js')
      },
      titleBarStyle: 'default',
      show: false, // Não mostrar até estar pronto
      icon: path.join(__dirname, '../../public/assets/icons/app-icon.png')
    });

    // Carregar a aplicação
    if (isDev) {
      this.mainWindow.loadURL('http://localhost:3000');
      // Abrir DevTools em desenvolvimento
      this.mainWindow.webContents.openDevTools();
    } else {
      this.mainWindow.loadFile(path.join(__dirname, '../../build/index.html'));
    }

    // Mostrar janela quando estiver pronta
    this.mainWindow.once('ready-to-show', () => {
      this.mainWindow.show();
      
      // Focar na janela
      if (isDev) {
        this.mainWindow.focus();
      }
    });

    // Emitir evento quando a janela for fechada
    this.mainWindow.on('closed', () => {
      this.mainWindow = null;
    });

    // Prevenir navegação externa
    this.mainWindow.webContents.on('will-navigate', (event, navigationUrl) => {
      const parsedUrl = new URL(navigationUrl);
      
      if (parsedUrl.origin !== 'http://localhost:3000' && parsedUrl.origin !== 'file://') {
        event.preventDefault();
      }
    });

    return this.mainWindow;
  }

  getMainWindow() {
    return this.mainWindow;
  }
}

const windowManager = new WindowManager();

// Evento quando o Electron terminou de inicializar
app.whenReady().then(() => {
  windowManager.createMainWindow();

  app.on('activate', () => {
    // No macOS, recriar janela quando o ícone do dock for clicado
    if (BrowserWindow.getAllWindows().length === 0) {
      windowManager.createMainWindow();
    }
  });
});

// Sair quando todas as janelas forem fechadas
app.on('window-all-closed', () => {
  // No macOS, aplicações ficam ativas até que o usuário saia explicitamente
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Segurança: Prevenir criação de novas janelas
app.on('web-contents-created', (event, contents) => {
  contents.on('new-window', (event, navigationUrl) => {
    // Prevenir abertura de novas janelas
    event.preventDefault();
  });
});

module.exports = { windowManager };
